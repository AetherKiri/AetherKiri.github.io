-- 缘染此叶、化作恋红：守夜人汉化组 ver2.0，Aether 本地兼容加载。
-- aether_chs 中的 119 个脚本来自本目录已有的汉化启动器。
-- 原 ARC 保留；此覆盖目录只在 Aether 启动时由 Lua 挂载。
assert(aether.api_version == 1 and aether.engine == "bgi",
       "This translation hook requires Aether BGI Lua API v1")
assert(aether.exists("aether_chs/00com_01"),
       "Missing aether_chs: keep the translation folder next to aether.lua")
aether.mount_dir("aether_chs")
aether.set_encoding("GBK")
-- msmincho.ttc 缺少部分简体字，混用补字字体会造成字号不一致。
-- 此汉化文本使用标准 GBK，统一使用 Aether 默认的完整中文字体。
aether.log("Loaded Yorikure ver2.0 Chinese scenario overlay (GBK)")
